<?php get_header();
$home_url = get_home_url();

$hero_banner_video_background = get_field('hero_banner_video_background');
$hero_banner_title = get_field('hero_banner_title');
$hero_banner_description = get_field('hero_banner_description');
$hero_banner_button = get_field('hero_banner_button');
$hero_banner_button_url = is_string($hero_banner_button) ? $hero_banner_button : (is_array($hero_banner_button) && isset($hero_banner_button['url']) ? $hero_banner_button['url'] : '');
$hero_banner_button_title = is_array($hero_banner_button) && !empty($hero_banner_button['title']) ? $hero_banner_button['title'] : 'See your numbers';
$hero_banner_button_target = is_array($hero_banner_button) && !empty($hero_banner_button['target']) ? $hero_banner_button['target'] : '_blank';
$hero_banner_card_content_list = get_field('hero_banner_card_content_list');

$we_handle_all_title = get_field('we_handle_all_title');
$we_handle_all_description = get_field('we_handle_all_description');
$we_handle_all_card_content_list = get_field('we_handle_all_card_content_list');

$traditional_vs_phoenix_title = get_field('traditional_vs_phoenix_title');
$traditional_vs_phoenix_content_list = get_field('traditional_vs_phoenix_content_list');

$commercial_project_title = get_field('commercial_project_title');
$commercial_project_desctiption = get_field('commercial_project_desctiption');
$commercial_project_content_list = get_field('commercial_project_content_list');

$what_we_dont_ask_for_title = get_field('what_we_dont_ask_for_title');
$what_we_dont_ask_for_description = get_field('what_we_dont_ask_for_description');
$what_we_dont_ask_for_question = get_field('what_we_dont_ask_for_question');
//Template Name: New Homepage
?>
<section class="banner">
    <video class="video-bg" autoplay="" loop="true" muted="" style="display: inline;" onloadedmetadata="this.currentTime = 0;" ontimeupdate="if(this.currentTime > 7) this.currentTime = 0;">
        <source src="" type="video/mp4">
        <source src="<?php echo esc_url($hero_banner_video_background); ?>" type="video/mp4">
    </video>
    <div class="video_overlay"></div>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-8">
                    <div class="content pe-lg-5">
                        <?php
                        if ($hero_banner_title) {
                        ?>
                            <h1 class="text-white"><?php echo esc_html($hero_banner_title); ?></h1>
                        <?php
                        }
                        ?>
                        <?php
                        if ($hero_banner_description) {
                        ?>
                            <?php echo wp_kses_post($hero_banner_description); ?>
                        <?php
                        }
                        ?>
                        <?php
                        if ($hero_banner_button_url) {
                        ?>
                            <a href="<?php echo esc_url($hero_banner_button_url); ?>" target="<?php echo esc_attr($hero_banner_button_target); ?>" rel="noopener noreferrer" class="yellow_btn"><?php echo esc_html($hero_banner_button_title); ?></a>
                        <?php
                        } else {
                        ?>
                            <a href="<?php echo esc_url($home_url . '/'); ?>" target="_blank" rel="noopener noreferrer" class="yellow_btn">See your numbers</a>
                        <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php
                if ($hero_banner_card_content_list) {
                    foreach ($hero_banner_card_content_list as $card) {
                ?>
                        <div class="col-md-4 col-sm-6">
                            <div class="content">
                                <h3 class="text-white"><?php echo isset($card['hero_banner_content_list_title']) ? esc_html($card['hero_banner_content_list_title']) : ''; ?></h3>
                                <?php echo isset($card['hero_banner_content_list_description']) ? wp_kses_post($card['hero_banner_content_list_description']) : ''; ?>
                            </div>
                        </div>
                <?php
                    }
                }
                ?>
            </div>
        </div>
    </div>
</section>

<section class="we_handle_all_the_complexity">
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="header mx-auto">
                        <?php
                        if ($we_handle_all_title) {
                        ?>
                            <h2 class="text-white text-center"><?php echo esc_html($we_handle_all_title); ?></h2>
                        <?php
                        }
                        if ($we_handle_all_description) {
                            echo wp_kses_post($we_handle_all_description);
                        }
                        ?>
                    </div>
                </div>
                <?php
                if ($we_handle_all_card_content_list) {
                    foreach ($we_handle_all_card_content_list as $card) {
                ?>
                        <div class="col-lg-4 col-md-6">
                            <div class="content">
                                <?php if (!empty($card['we_handle_all_card_content_list_small_text'])): ?>
                                    <span class="small_text"><?php echo esc_html($card['we_handle_all_card_content_list_small_text']); ?></span>
                                <?php endif; ?>
                                <?php if (!empty($card['we_handle_all_card_content_list_title'])): ?>
                                    <h3 class="text-white"><?php echo esc_html($card['we_handle_all_card_content_list_title']); ?></h3>
                                <?php endif; ?>
                                <?php if (!empty($card['we_handle_all_card_content_list_description'])): ?>
                                    <div class="text-white mb-0"><?php echo wp_kses_post($card['we_handle_all_card_content_list_description']); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                <?php
                    }
                }
                ?>
            </div>
        </div>
    </div>
</section>

<section class="traditional_financing pb-0">
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="header">
                        <h2 class="text-white text-center mb-5"><?php echo $traditional_vs_phoenix_title ? wp_kses_post($traditional_vs_phoenix_title) : 'Traditional vs. <span class="text-gold">Phoenix</span>'; ?></h2>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="comparison_table">
                        <div class="table_header">
                            <div class="col_factor"></div>
                            <div class="col_traditional">Traditional</div>
                            <div class="col_phoenix text-gold">Phoenix</div>
                        </div>
                        <?php if ($traditional_vs_phoenix_content_list) : ?>
                            <?php foreach ($traditional_vs_phoenix_content_list as $item) : ?>
                                <div class="table_row">
                                    <div class="col_factor"><?php echo !empty($item['traditional_vs_phoenix_content_list_title']) ? esc_html($item['traditional_vs_phoenix_content_list_title']) : ''; ?></div>
                                    <div class="col_traditional">
                                        <svg class="icon_x" width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M2 2L12 12M12 2L2 12" stroke="#e05555" stroke-width="2" stroke-linecap="round" />
                                        </svg>
                                        <?php echo !empty($item['traditional_vs_phoenix_traditional']) ? esc_html($item['traditional_vs_phoenix_traditional']) : ''; ?>
                                    </div>
                                    <div class="col_phoenix">
                                        <svg class="icon_check" width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M2 7L5.5 10.5L12 4" stroke="#c59b32" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                        <?php echo !empty($item['traditional_vs_phoenix_phoenix']) ? esc_html($item['traditional_vs_phoenix_phoenix']) : ''; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <div class="table_row">
                                <div class="col_factor">Initial Capital Required</div>
                                <div class="col_traditional">
                                    <svg class="icon_x" width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M2 2L12 12M12 2L2 12" stroke="#e05555" stroke-width="2" stroke-linecap="round" />
                                    </svg>
                                    35% Down Payment
                                </div>
                                <div class="col_phoenix">
                                    <svg class="icon_check" width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M2 7L5.5 10.5L12 4" stroke="#c59b32" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                    10% Capital Commitment
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="commercial_project">
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-lg-12">
                    <div class="header">
                        <h2 class="text-center mb-4 text-white"><?php echo $commercial_project_title ? esc_html($commercial_project_title) : 'Commercial Project Eligibility & No-Guarantee Financing'; ?></h2>
                        <?php if ($commercial_project_desctiption) : ?>
                            <div class="text-white"><?php echo wp_kses_post($commercial_project_desctiption); ?></div>
                        <?php else : ?>
                            <p class="text-white">Each program is designed with clear timelines, eligibility requirements, and compliance protections.</p>
                        <?php endif; ?>
                    </div>
                </div>
                <?php if ($commercial_project_content_list) : ?>
                    <?php foreach ($commercial_project_content_list as $item) : ?>
                        <div class="col-lg-4 col-md-6">
                            <div class="content">
                                <h3 class="text-white">
                                    <?php if (!empty($item['commercial_project_content_list_image'])) : ?>
                                        <img src="<?php echo esc_url($item['commercial_project_content_list_image']); ?>" alt="<?php echo !empty($item['commercial_project_content_list_title']) ? esc_attr($item['commercial_project_content_list_title']) : ''; ?>" loading="lazy">
                                    <?php endif; ?>
                                    <?php echo !empty($item['commercial_project_content_list_title']) ? esc_html($item['commercial_project_content_list_title']) : ''; ?>
                                </h3>
                                <div class="text-white"><?php echo !empty($item['commercial_project_content_list_description']) ? wp_kses_post($item['commercial_project_content_list_description']) : ''; ?></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else : ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="content">
                            <h3 class="text-white">SEED</h3>
                            <p class="text-white">A strategic program designed to transform controlled liquidity into large-scale banking instruments for monetization and long-term capital expansion.</p>
                        </div>
                    </div>
                <?php endif; ?>

            </div>
        </div>
    </div>
</section>

<section class="how_phoenix_scales bg-black">
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="header">
                        <h2 class="text-center text-white mb-0">How Phoenix <span>Scales</span> Your Portfolio</h2>
                    </div>
                </div>

                <div class="col-lg-4 mb-4">
                    <div class="stat-card">
                        <div class="card-label">Scenario 01</div>
                        <h3 class="text-white">Single $100M Project</h3>
                        <div class="data-rows">
                            <div class="data-row">
                                <span class="label">Year 10 Value</span>
                                <span class="value">$244.4M</span>
                            </div>
                            <div class="data-row">
                                <span class="label">Traditional Profit</span>
                                <span class="value">$31.6M</span>
                            </div>
                            <div class="data-row">
                                <span class="label">Phoenix Profit</span>
                                <span class="value">$76.9M</span>
                            </div>
                        </div>
                        <div class="result_highlight">
                            <span class="result_label">Difference</span>
                            <span class="result_value">+$45.3M</span>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 mb-4">
                    <div class="stat-card">
                        <div class="card-label">Scenario 02</div>
                        <h3 class="text-white">$300M Portfolio</h3>
                        <div class="comparison-rows">
                            <div class="comparison-row">
                                <span class="badge badge-traditional">Traditional</span>
                                <span class="comp-text">3 deals possible with $100M capital</span>
                            </div>
                            <div class="comparison-row phoenix-row">
                                <span class="badge badge-phoenix">Phoenix</span>
                                <span class="comp-text">10 deals possible with same $100M capital</span>
                            </div>
                        </div>
                        <div class="result_highlight">
                            <span class="result_label">Additional Deals</span>
                            <span class="result_value">+7 deals</span>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 mb-4">
                    <div class="stat-card">
                        <div class="card-label">Scenario 03</div>
                        <h3 class="text-white">Generational Wealth</h3>
                        <div class="data-rows">
                            <div class="data-row">
                                <span class="label">Traditional Equity</span>
                                <span class="value">$60M</span>
                            </div>
                            <div class="data-row">
                                <span class="label">Phoenix Equity</span>
                                <span class="value text-gold">$650M+</span>
                            </div>
                        </div>
                        <div class="result_highlight">
                            <span class="result_label">Difference</span>
                            <span class="result_value">$590M+</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="bottom_text">
                        <p class="text-center text-white"><i><b>That <span>$250M difference</span> isn't a financial metric — it's generational wealth creation.</b></i></p>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>

<!-- <section class="our_5_point_project">
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-md-12">
                    <div class="header">
                        <h2 class="text-white mb-0">Our 5-Point Project Assessment</h2>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="content">
                        <div class="card-front">
                            <svg width="40" height="40" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M15 2C10.582 2 7 5.582 7 10c0 6.627 8 18 8 18s8-11.373 8-18c0-4.418-3.582-8-8-8z" stroke="#c59b32" stroke-width="2" stroke-linejoin="round" />
                                <circle cx="15" cy="10" r="3" stroke="#c59b32" stroke-width="2" />
                            </svg>
                            <h3 class="text-white mb-0">Project Location</h3>
                        </div>
                        <div class="card-back">
                            <h3>Project Location</h3>
                            <p><strong>"Is it in a prime, high-growth area?"</strong></p>
                            <p><i>Why:</i> Strong locations = strong returns</p>
                            <p>Your Job: Validate the market opportunity</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="content">
                        <div class="card-front">
                            <svg width="40" height="40" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <ellipse cx="15" cy="8" rx="8" ry="3" stroke="#c59b32" stroke-width="2" />
                                <path d="M7 8v5c0 1.657 3.582 3 8 3s8-1.343 8-3V8" stroke="#c59b32" stroke-width="2" />
                                <path d="M7 13v5c0 1.657 3.582 3 8 3s8-1.343 8-3v-5" stroke="#c59b32" stroke-width="2" />
                            </svg>
                            <h3 class="text-white mb-0">Funding Amount</h3>
                        </div>
                        <div class="card-back">
                            <h3>Funding Amount</h3>
                            <p><strong>"Is the requested funding sufficient?"</strong></p>
                            <p><i>Why:</i> Incomplete projects = dead money</p>
                            <p>Your Job: Confirm construction budget is realistic</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="content">
                        <div class="card-front">
                            <svg width="40" height="40" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect x="4" y="10" width="10" height="18" stroke="#c59b32" stroke-width="2" stroke-linejoin="round" />
                                <path d="M14 16h8V28H14" stroke="#c59b32" stroke-width="2" stroke-linejoin="round" />
                                <path d="M9 4l5 6H4L9 4z" stroke="#c59b32" stroke-width="2" stroke-linejoin="round" />
                                <rect x="7" y="18" width="3" height="3" stroke="#c59b32" stroke-width="1.2" />
                                <rect x="17" y="20" width="3" height="3" stroke="#c59b32" stroke-width="1.2" />
                            </svg>
                            <h3 class="text-white mb-0">Project Type</h3>
                        </div>
                        <div class="card-back">
                            <h3>Project Type</h3>
                            <p><strong>"Commercial, residential, or mixed-use?"</strong></p>
                            <p><i>Why:</i> We know how to value these</p>
                            <p>Your Job: Speak to why this asset class works</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="content">
                        <div class="card-front">
                            <svg width="40" height="40" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M15 3L5 7v8c0 5.523 4.477 10 10 10s10-4.477 10-10V7L15 3z" stroke="#c59b32" stroke-width="2" stroke-linejoin="round" />
                                <path d="M10.5 15l3 3 6-6" stroke="#c59b32" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                            <h3 class="text-white mb-0">Collateral</h3>
                        </div>
                        <div class="card-back">
                            <h3>Collateral</h3>
                            <p><strong>"What hard assets back this deal?"</strong></p>
                            <p><i>Why:</i> Asset-backed = lower risk</p>
                            <p>Your Job: Document the collateral value</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="content">
                        <div class="card-front">
                            <svg width="40" height="40" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M4 24h22" stroke="#c59b32" stroke-width="2" stroke-linecap="round" />
                                <path d="M4 24V6" stroke="#c59b32" stroke-width="2" stroke-linecap="round" />
                                <path d="M7 18l5-5 4 3 7-8" stroke="#c59b32" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                <circle cx="23" cy="8" r="2" stroke="#c59b32" stroke-width="2" />
                            </svg>
                            <h3 class="text-white mb-0">Projected NOI</h3>
                        </div>
                        <div class="card-back">
                            <h3>Projected NOI</h3>
                            <p><strong>"Will the project cover debt 3 years post-stabilization?"</strong></p>
                            <p><i>Why:</i> Sustainability = long-term profit</p>
                            <p>Your Job: Show how the numbers work</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section> -->

<section class="what_we_dont_ask">
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="header">
                        <h2 class="text-white mb-4"><?php echo $what_we_dont_ask_for_title ? esc_html($what_we_dont_ask_for_title) : "What We Don't Ask For"; ?></h2>
                        <div class="text-white mb-0"><?php echo $what_we_dont_ask_for_description ? wp_kses_post($what_we_dont_ask_for_description) : "We evaluate your project, not your balance sheet. That's partnership."; ?></div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="content">
                        <?php if ($what_we_dont_ask_for_question) : ?>
                            <?php foreach ($what_we_dont_ask_for_question as $item) : ?>
                                <div class="list-item">
                                    <div class="icon">
                                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <circle cx="8" cy="8" r="7" stroke="#c59b32" stroke-width="1.5" />
                                            <path d="M5.5 5.5L10.5 10.5M10.5 5.5L5.5 10.5" stroke="#c59b32" stroke-width="1.5" stroke-linecap="round" />
                                        </svg>
                                    </div>
                                    <p class="text-white mb-0"><?php echo !empty($item['what_we_dont_ask_for_question_text']) ? esc_html($item['what_we_dont_ask_for_question_text']) : ''; ?></p>
                                </div>
                            <?php endforeach; ?>
                        <?php else : ?>
                            <div class="list-item">
                                <div class="icon">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <circle cx="8" cy="8" r="7" stroke="#c59b32" stroke-width="1.5" />
                                        <path d="M5.5 5.5L10.5 10.5M10.5 5.5L5.5 10.5" stroke="#c59b32" stroke-width="1.5" stroke-linecap="round" />
                                    </svg>
                                </div>
                                <p class="text-white mb-0">Personal guarantees</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php get_footer(); ?>