<footer>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-4 col-lg-4 col-md-6">
                    <div class="disclosure">
                        <h3>Disclosure</h3>
                        <p>Phoenix Capital Solutions is headquartered in West Palm Beach, Florida, and serves
                            qualified investors across North America, Europe, Asia, and select global markets. Our
                            team maintains international access to institutional banking networks and vetted
                            monetization partners.</p>
                        <h3>Serving qualified clients globally</h3>
                        <p><strong>Headquarters:</strong><a href="#">West Palm Beach, FL</a></p>
                    </div>
                </div>
                <div class="col-xl col-lg-4 col-md-6">
                    <div class="navigation-links">
                        <h3>Quick Links</h3>
                        <?php
                        // wp_nav_menu(array(
                        //     'menu'            => 'navigation-links', // Targets the specific menu name
                        //     'container'       => false,
                        //     'items_wrap'      => '<ul>%3$s</ul>', // Clean UL without extra classes
                        //     'walker'          => new class extends Walker_Nav_Menu {
                        //         function start_el(&$output, $item, $depth = 0, $args = null, $id = 0)
                        //         {
                        //             // Get standard WordPress menu classes if needed (like 'current-menu-item')
                        //             $classes = empty($item->classes) ? array() : (array) $item->classes;
                        //             $class_names = join(' ', apply_filters('nav_menu_css_class', array_filter($classes), $item, $args, $depth));
                        //             $class_names = $class_names ? ' class="' . esc_attr($class_names) . '"' : '';

                        //             $output .= '<li' . $class_names . '>';

                        //             $atts = array();
                        //             $atts['title']  = ! empty($item->attr_title) ? $item->attr_title : '';
                        //             $atts['target'] = ! empty($item->target)     ? $item->target     : '';
                        //             $atts['rel']    = ! empty($item->xfn)        ? $item->xfn        : '';
                        //             $atts['href']   = ! empty($item->url)        ? $item->url        : '';

                        //             $atts = apply_filters('nav_menu_link_attributes', $atts, $item, $args, $depth);
                        //             $attributes = '';
                        //             foreach ($atts as $attr => $value) {
                        //                 if (! empty($value)) {
                        //                     $value = ('href' === $attr) ? esc_url($value) : esc_attr($value);
                        //                     $attributes .= ' ' . $attr . '="' . $value . '"';
                        //                 }
                        //             }

                        //             $title = apply_filters('the_title', $item->title, $item->ID);
                        //             $title = apply_filters('nav_menu_item_title', $title, $item, $args, $depth);

                        //             $item_output = $args->before;
                        //             $item_output .= '<a' . $attributes . '>';
                        //             $item_output .= $args->link_before . $title . $args->link_after;
                        //             $item_output .= '</a>';
                        //             $item_output .= $args->after;

                        //             $output .= apply_filters('walker_nav_menu_start_el', $item_output, $item, $depth, $args);
                        //         }
                        //         function end_el(&$output, $item, $depth = 0, $args = null)
                        //         {
                        //             $output .= "</li>\n";
                        //         }
                        //     }
                        // ));

                        $pages = get_pages();
                        if ($pages) {
                            echo '<ul>';
                            foreach ($pages as $page) {
                                echo '<li><a href="' . get_permalink($page->ID) . '">' . $page->post_title . '</a></li>';
                            }
                            echo '</ul>';
                        }
                        ?>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6">
                    <div class="contact-details">
                        <h3>Contact Details</h3>
                        <div class="contact-item">
                            <p>General Inquiries: <a
                                    href="mailto:info@phxcapsolutions.com">info@phxcapsolutions.com</a></p>
                            <p>Compliance: <a
                                    href="mailto:compliance@phxcapsolutions.com">compliance@phxcapsolutions.com</a>
                            </p>
                            <p>Executive Office: <a
                                    href="mailto:executive@phxcapsolutions.com">executive@phxcapsolutions.com</a>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-4 col-md-6">
                    <div class="contact_details">
                        <div class="contact-item">
                            <h4>Phone</h4>
                            <a href="tel:+09123456789">09123456789</a>
                        </div>
                        <div class="contact-item">
                            <h4>Business Hours</h4>
                            <p>Monday-Friday<br>9:00 AM - 5:00 PM EST</p>
                            <p>By-appointment consultations available upon request.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-4">
                <div class="col-12 text-center">
                    <p class="copyright">2025 Copyright FMO Media</p>
                </div>
            </div>
        </div>
    </div>
    <button id="backToTop" class="back-to-top" type="button" aria-label="Back to top">↑</button>
</footer>
<div id="cookieNotice" class="cookie-notice" role="dialog" aria-live="polite" aria-label="Cookie notice">
    <div class="wrapper">
        <div class="cookie-notice__inner">
            <p class="cookie-notice__text text-white">
                The information provided by Phoenix Capital Solutions, Inc. (“we,” “us,” or “our”) on phxcapsolutions.com (the “Site”) is for general information purposes only. All information on the Site is provided in good faith, however we make no representation or warranty of any kind, express or implied, regarding the accuracy, adequacy, validity, reliability, availability, or completeness of any information on the Site. UNDER NO CIRCUMSTANCE SHALL WE HAVE ANY LIABILITY TO YOU FOR ANY LOSS OR DAMAGE OF ANY KIND INCURRED AS A RESULT OF THE USE OF THE SITE OR RELIANCE ON ANY INFORMATION PROVIDED ON THE SITE. YOUR USE OF THE SITE AND YOUR RELIANCY ON ANY INFORMATION ON THE SITE IS SOLELY AT YOUR OWN RISK.
            </p>
            <button id="cookieAcceptBtn" class="cookie-notice__btn" type="button">Accept</button>
        </div>
    </div>
</div>

<script>
    (function() {
        var notice = document.getElementById('cookieNotice');
        var cookieBtn = document.getElementById('cookieAcceptBtn');
        var backToTopBtn = document.getElementById('backToTop');
        var cookieName = 'phx_cookie_notice_accepted';

        if (!notice || !cookieBtn) return;

        // Check if cookie exists
        if (document.cookie.split(';').some(item => item.trim().startsWith(cookieName))) {
            notice.style.display = 'none';
        } else {
            cookieBtn.addEventListener('click', function() {
                // Set cookie to expire in 24 hours
                var date = new Date();
                date.setTime(date.getTime() + (24 * 60 * 60 * 1000));
                var expires = 'expires=' + date.toUTCString();
                document.cookie = cookieName + '=true; ' + expires + '; path=/; SameSite=Lax';
                notice.style.display = 'none';
            });
        }

        // Back to Top Button
        if (!backToTopBtn) return;

        const toggleButton = () => {
            if (window.scrollY > 200) {
                backToTopBtn.classList.add('show');
            } else {
                backToTopBtn.classList.remove('show');
            }
        };

        window.addEventListener('scroll', toggleButton, {
            passive: true
        });
        toggleButton();

        backToTopBtn.addEventListener('click', function() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    })();
</script>
<?php wp_footer(); ?>
</body>

</html>