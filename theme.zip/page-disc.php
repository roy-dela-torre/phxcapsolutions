<?php
/*
Template Name: D.I.S.C. Page
*/

get_header();
$img_path = get_template_directory_uri() . '/assets/img/disc';
?>

<main class="disc_page">

    <!-- ========== HERO ========== -->
    <section class="disc_hero">
        <div class="wrapper">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="hero_content pe-lg-5">
                            <div class="program_label">Debt Instrument Structured Capitalization Program</div>
                            <h1 class="text-white mb-5">Convert Qualified Debt Instruments Into Structured Capital</h1>
                            <img loading="lazy" class="d-block d-lg-none mb-4" src="<?php echo $img_path; ?>/disc-hero.svg" alt="D.I.S.C. Program" />
                            <p class="mb-5">The D.I.S.C. Program provides a compliant, strategic pathway for clients to leverage verified debt instruments or financial assets into structured capital flows without traditional lending barriers.</p>
                            <div class="hero_btns">
                                <a href="/contact" class="btn_gold">Request a Confidential Consultation</a>
                                <a href="#" class="btn_outline">Download Program Overview</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 d-none d-lg-block">
                        <div class="hero_image">
                            <img loading="lazy" src="<?php echo $img_path; ?>/disc-hero.svg" alt="D.I.S.C. Program" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ========== PROGRAM OVERVIEW ========== -->
    <section class="disc_overview">
        <div class="wrapper">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="overview_content pe-lg-5">
                            <h2 class="text-white mb-4">Program Overview</h2>
                            <img loading="lazy" src="<?php echo $img_path; ?>/disc-overview.svg" alt="D.I.S.C. Program Overview" class="mb-4 d-block d-lg-none" />
                            <p>The Debt Instrument Structured Capitalization (D.I.S.C.) Program is designed for qualified clients seeking compliant financial pathways, allowing clients to activate capital flow without conventional loans, dilution of assets, or unnecessary risk exposure.</p>
                            <p>Unlike traditional financing models that rely on commercial underwriting or collateral liquidation, the D.I.S.C. Program leverages alternative institutional structures to create efficient, compliance-led capitalization solutions.</p>
                            <p class="mb-0">Clients benefit from a controlled, documented, and secure process that aligns with institutional risk protocols, regulatory requirements, and structured monetization pathways.</p>
                        </div>
                    </div>
                    <div class="col-lg-6 d-none d-lg-block">
                        <div class="overview_image">
                            <img loading="lazy" src="<?php echo $img_path; ?>/disc-overview.svg" alt="D.I.S.C. Program Overview" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ========== PROGRAM MECHANICS (FLIP CARDS) ========== -->
    <section class="disc_mechanics">
        <div class="wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section_header text-center mb-5">
                            <h2 class="text-white">Program Mechanics</h2>
                        </div>
                    </div>

                    <!-- Card 1 -->
                    <div class="col-lg-6">
                        <div class="flip_card">
                            <div class="flip_card_inner">
                                <div class="flip_card_front">
                                    <h3 class="text-white mb-0">Asset Verification &amp; Compliance Review</h3>
                                </div>
                                <div class="flip_card_back">
                                    <h3 class="text-gold mb-3">Asset Verification &amp; Compliance Review</h3>
                                    <p>Each client's debt instrument or financial asset undergoes a thorough verification process, including documentation review, valuation confirmation, compliance screening, and institutional validation. Only instruments that meet all standards may advance to the capitalization phase.</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Card 2 -->
                    <div class="col-lg-6">
                        <div class="flip_card">
                            <div class="flip_card_inner">
                                <div class="flip_card_front">
                                    <h3 class="text-white mb-0">Structured Capitalization Pathway</h3>
                                </div>
                                <div class="flip_card_back">
                                    <h3 class="text-gold mb-3">Structured Capitalization Pathway</h3>
                                    <p>Once approved, the instrument is used within a structured framework to generate capital flow. This may involve monetization, credit enhancement, or structured financial positioning depending on the nature of the asset and approved institutional pathways.</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Card 3 -->
                    <div class="col-lg-6">
                        <div class="flip_card">
                            <div class="flip_card_inner">
                                <div class="flip_card_front">
                                    <h3 class="text-white mb-0">Institutional Processing</h3>
                                </div>
                                <div class="flip_card_back">
                                    <h3 class="text-gold mb-3">Institutional Processing</h3>
                                    <p>Qualified instruments are processed through institutional partners capable of validating, monetizing, or otherwise converting them into structured capital. All processing follows documented review protocols and compliance standards throughout the program lifecycle.</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Card 4 -->
                    <div class="col-lg-6">
                        <div class="flip_card">
                            <div class="flip_card_inner">
                                <div class="flip_card_front">
                                    <h3 class="text-white mb-0">Controlled Capital Use</h3>
                                </div>
                                <div class="flip_card_back">
                                    <h3 class="text-gold mb-3">Controlled Capital Use</h3>
                                    <p>A portion of processed capital may be withdrawn for approved purposes, while remaining portions must be reinvested or deployed according to compliance expectations and program rules. All capital use is documented and subject to institutional oversight.</p>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>

    <!-- ========== PROGRAM TIMELINE (FLIP CARDS) ========== -->
    <section class="disc_timeline">
        <div class="wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section_header text-center mb-3">
                            <h2 class="text-white">Program Timeline</h2>
                        </div>
                        <p class="timeline_note text-center mb-5">Timelines vary based on asset verification, institutional processing, and compliance requirements. All participants follow the structured phases outlined below from initial submission through capital distribution.</p>
                    </div>

                    <!-- Phase 1 -->
                    <div class="col-lg-6">
                        <div class="flip_card">
                            <div class="flip_card_inner">
                                <div class="flip_card_front">
                                    <div class="phase_tag">Weeks 1–2</div>
                                    <h3 class="text-white mb-0">Documentation &amp; Compliance Screening</h3>
                                </div>
                                <div class="flip_card_back">
                                    <div class="phase_tag">Weeks 1–2</div>
                                    <p>Submission of all supporting documents, KYC/AML verification, CIS completion, and preliminary assessment. All documentation is reviewed against institutional standards before proceeding to the validation phase.</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Phase 2 -->
                    <div class="col-lg-6">
                        <div class="flip_card">
                            <div class="flip_card_inner">
                                <div class="flip_card_front">
                                    <div class="phase_tag">Weeks 2–4</div>
                                    <h3 class="text-white mb-0">Instrument Validation</h3>
                                </div>
                                <div class="flip_card_back">
                                    <div class="phase_tag">Weeks 2–4</div>
                                    <p>Institutional partners verify the authenticity, value, and eligibility of the debt instrument or financial asset. If the instrument fails validation at this stage, the program cannot proceed and no capitalization occurs.</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Phase 3 -->
                    <div class="col-lg-6">
                        <div class="flip_card">
                            <div class="flip_card_inner">
                                <div class="flip_card_front">
                                    <div class="phase_tag">Weeks 4–8</div>
                                    <h3 class="text-white mb-0">Structured Capitalization</h3>
                                </div>
                                <div class="flip_card_back">
                                    <div class="phase_tag">Weeks 4–8</div>
                                    <p>Once validated, the instrument moves through approved financial pathways to begin producing structured capital flow. The capitalization structure is tailored to the instrument type, compliance restrictions, and institutional requirements.</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Phase 4 -->
                    <div class="col-lg-6">
                        <div class="flip_card">
                            <div class="flip_card_inner">
                                <div class="flip_card_front">
                                    <div class="phase_tag">Week 8+</div>
                                    <h3 class="text-white mb-0">Distribution &amp; Reinvestment Phases</h3>
                                </div>
                                <div class="flip_card_back">
                                    <div class="phase_tag">Week 8+</div>
                                    <p>Clients begin receiving capital disbursements according to program guidelines, with reinvestment requirements applied based on the instrument type and compliance restrictions. Ongoing oversight ensures continued alignment with institutional standards.</p>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>

    <!-- ========== FINANCIAL MODEL ========== -->
    <section class="disc_financial_model">
        <div class="wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section_header text-center mb-3">
                            <h2 class="text-white">Financial Model</h2>
                        </div>
                        <p class="model_intro text-center">The D.I.S.C. Program offers a structured approach to capitalizing approved debt instruments. A portion of generated capital may be utilized for approved purposes, while remaining funds are reinvested or allocated according to program requirements. All outcomes depend on institutional processes and compliance results.</p>
                    </div>

                    <div class="col-lg-12">
                        <div class="model_cards">
                            <div class="model_card">
                                <p>A verified debt instrument is submitted for program evaluation</p>
                            </div>
                            <div class="model_card">
                                <p>Post-validation, the instrument enters a structured capitalization process</p>
                            </div>
                            <div class="model_card">
                                <p>Capital flow begins based on approved institutional pathways</p>
                            </div>
                            <div class="model_card">
                                <p>A portion may be utilized for approved client purposes</p>
                            </div>
                            <div class="model_card">
                                <p>Remaining funds are reinvested or allocated per program requirements</p>
                            </div>
                        </div>
                        <p class="model_disclaimer text-center">This example is illustrative only and does not guarantee performance or outcomes.</p>
                    </div>

                </div>
            </div>
        </div>
    </section>

    <!-- ========== ELIGIBILITY REQUIREMENTS ========== -->
    <section class="disc_eligibility">
        <div class="wrapper">
            <div class="container-fluid">
                <div class="row justify-content-center">
                    <div class="col-lg-12">
                        <div class="section_header text-center mb-3">
                            <h2 class="text-white">Eligibility Requirements</h2>
                        </div>
                        <p class="eligibility_intro text-center mb-5">To participate in the D.I.S.C. Program, clients must meet strict standards, including:</p>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="eligibility_card">
                            <div class="elig_icon">
                                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" stroke="#c59b32" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                            </div>
                            <p class="mb-0">Ownership of a legitimate, verifiable debt instrument or other approved financial asset</p>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="eligibility_card">
                            <div class="elig_icon">
                                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6z" stroke="#c59b32" stroke-width="1.8" stroke-linejoin="round" />
                                    <path d="M14 2v6h6M16 13H8M16 17H8M10 9H8" stroke="#c59b32" stroke-width="1.8" stroke-linecap="round" />
                                </svg>
                            </div>
                            <p class="mb-0">Complete CIS, KYC, AML, and all required documentation submissions</p>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="eligibility_card">
                            <div class="elig_icon">
                                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" stroke="#c59b32" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                            </div>
                            <p class="mb-0">Ability to meet valuation and compliance requirements set by institutional partners</p>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="eligibility_card">
                            <div class="elig_icon">
                                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" stroke="#c59b32" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                            </div>
                            <p class="mb-0">Demonstrated need for structured capital flow through compliant financial channels</p>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="eligibility_card">
                            <div class="elig_icon">
                                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect x="2" y="3" width="20" height="18" rx="2" stroke="#c59b32" stroke-width="1.8" />
                                    <path d="M7 8h10M7 12h6" stroke="#c59b32" stroke-width="1.8" stroke-linecap="round" />
                                </svg>
                            </div>
                            <p class="mb-0">Commitment to program rules, reinvestment requirements, and eligibility review processes</p>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6">
                        <div class="eligibility_card">
                            <div class="elig_icon">
                                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <circle cx="12" cy="12" r="10" stroke="#c59b32" stroke-width="1.8" />
                                    <path d="M12 8v4l3 3" stroke="#c59b32" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                            </div>
                            <p class="mb-0">Willingness to undergo institutional validation, audit procedures, and ongoing compliance review</p>
                        </div>
                    </div>

                    <div class="col-lg-12 text-center mt-3">
                        <a href="/security-and-compliance/" class="btn_gold">Security and Compliance</a>
                    </div>

                </div>
            </div>
        </div>
    </section>

    <!-- ========== USE CASES ========== -->
    <section class="disc_use_cases">
        <div class="wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section_header text-center mb-3">
                            <h2 class="text-white">Generalized Use Cases</h2>
                        </div>
                        <p class="use_cases_intro text-center mb-5">These examples describe typical applications of the D.I.S.C. Program and do not represent real client cases.</p>
                    </div>

                    <div class="col-lg-4 mb-4">
                        <div class="use_case_card">
                            <div class="use_case_image">
                                <img loading="lazy" src="<?php echo $img_path; ?>/disc-usecase-1.jpg" alt="Business Expansion" />
                            </div>
                            <div class="use_case_content">
                                <p class="mb-0">A client with an overlooked or inactive debt instrument uses D.I.S.C. to convert it into structured capital for business expansion.</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 mb-4">
                        <div class="use_case_card">
                            <div class="use_case_image">
                                <img loading="lazy" src="<?php echo $img_path; ?>/disc-usecase-2.jpg" alt="Private Asset Holder" />
                            </div>
                            <div class="use_case_content">
                                <p class="mb-0">A private asset holder leverages D.I.S.C. to activate capital without liquidating significant holdings.</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 mb-4">
                        <div class="use_case_card">
                            <div class="use_case_image">
                                <img loading="lazy" src="<?php echo $img_path; ?>/disc-usecase-3.jpg" alt="Developer Use Case" />
                            </div>
                            <div class="use_case_content">
                                <p class="mb-0">A developer uses verified financial assets to secure structured capital for multi-phase project execution.</p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>

    <!-- ========== FAQ ========== -->
    <section class="disc_faq">
        <div class="wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section_header">
                            <h2 class="text-white">Frequently Asked Questions</h2>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="faq_accordion" id="discFaq">

                            <div class="faq_item">
                                <button class="faq_question collapsed" data-bs-toggle="collapse" data-bs-target="#disc-faq-1" aria-expanded="false">
                                    What happens if the instrument fails validation?
                                    <svg class="faq_icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M4 6l4 4 4-4" stroke="#c59b32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </button>
                                <div class="faq_answer collapse" id="disc-faq-1" data-bs-parent="#discFaq">
                                    <p>The program cannot proceed, and no capitalization occurs.</p>
                                </div>
                            </div>

                            <div class="faq_item">
                                <button class="faq_question collapsed" data-bs-toggle="collapse" data-bs-target="#disc-faq-2" aria-expanded="false">
                                    Can international clients participate?
                                    <svg class="faq_icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M4 6l4 4 4-4" stroke="#c59b32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </button>
                                <div class="faq_answer collapse" id="disc-faq-2" data-bs-parent="#discFaq">
                                    <p>Yes, provided they meet all compliance and verification requirements.</p>
                                </div>
                            </div>

                            <div class="faq_item">
                                <button class="faq_question collapsed" data-bs-toggle="collapse" data-bs-target="#disc-faq-3" aria-expanded="false">
                                    Are distributions guaranteed?
                                    <svg class="faq_icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M4 6l4 4 4-4" stroke="#c59b32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </button>
                                <div class="faq_answer collapse" id="disc-faq-3" data-bs-parent="#discFaq">
                                    <p>No. All capital outcomes depend on institutional processes, instrument viability, and compliance results.</p>
                                </div>
                            </div>

                            <div class="faq_item">
                                <button class="faq_question collapsed" data-bs-toggle="collapse" data-bs-target="#disc-faq-4" aria-expanded="false">
                                    What types of instruments qualify?
                                    <svg class="faq_icon" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M4 6l4 4 4-4" stroke="#c59b32" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </button>
                                <div class="faq_answer collapse" id="disc-faq-4" data-bs-parent="#discFaq">
                                    <p>Eligibility depends on verification, authenticity, valuation, and compliance screening. Only legitimate and fully documented instruments may qualify.</p>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


</main>

<?php get_footer(); ?>