<?php
if (!defined('ABSPATH')) {
    exit;
}

if (! function_exists('theme_setup')) :
    function theme_setup_setup()
    {
        add_theme_support('post-thumbnails');
        add_theme_support('post-formats', array('aside', 'gallery', 'quote', 'image', 'video'));
        add_theme_support('woocommerce');
        add_theme_support('wc-product-gallery-zoom');
        add_theme_support('wc-product-gallery-lightbox');
        add_theme_support('wc-product-gallery-slider');

        register_nav_menus(array(
            'primary' => __('Primary Menu', 'theme_setup'),
            'navigation-links' => __('Navigation links', 'theme_setup'),
        ));
    }
    add_action('after_setup_theme', 'theme_setup_setup');
endif;

function exam_enqueue_assets()
{
    $theme_uri = get_template_directory_uri();
    $is_homepage = is_front_page() || is_home();
    $font_awesome_kit_code = defined('PHX_FONT_AWESOME_KIT_CODE') ? (string) constant('PHX_FONT_AWESOME_KIT_CODE') : '';

    wp_enqueue_style('bootstrap', $theme_uri . '/inc/css/bootstrap.min.css', array(), null);
    wp_enqueue_style('global', $theme_uri . '/inc/css/global.css', array('bootstrap'), null);
    wp_enqueue_script('functions', $theme_uri . '/inc/js/functions.js', array('jquery', 'owl-carousel', 'aos'), null, true);

    if (!empty($font_awesome_kit_code)) {
        wp_enqueue_script('font-awesome-kit', 'https://kit.fontawesome.com/' . $font_awesome_kit_code . '.js', array(), null, false);
    }

    wp_enqueue_script('jquery');
    wp_enqueue_script('bootstrap', $theme_uri . '/inc/js/bootstrap.bundle.min.js', array('jquery'), null, true);

    if ($is_homepage) {
        wp_enqueue_style('new-homepage', $theme_uri . '/inc/css/new_homepage.css', array('global'), null);
        wp_enqueue_script('homepage', $theme_uri . '/inc/js/homepage.js', array('jquery'), null, true);
        wp_enqueue_script('functions', $theme_uri . '/inc/js/functions.js', array('jquery', 'owl-carousel', 'aos'), null, true);
    } elseif (is_page_template('page-gift.php')) {
        wp_enqueue_style('gift', $theme_uri . '/inc/css/gift.css', array('global'), null);
    } elseif (is_page('about-us') || is_page_template('page-about-us.php')) {
        wp_enqueue_style('about-us', $theme_uri . '/inc/css/about_us.css', array('global'), null);
    }
}
add_action('wp_enqueue_scripts', 'exam_enqueue_assets');
